﻿

using System;
using PeopleDepartment.CommonLibrary;

namespace PeopleDepartment
{
    public class Program
    {
        public static void Main()
        {
           
        }
    }
}